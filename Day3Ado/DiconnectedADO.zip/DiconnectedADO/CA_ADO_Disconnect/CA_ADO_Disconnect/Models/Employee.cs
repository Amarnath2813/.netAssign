﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp_ADO.Models
{
    public class Employee
    { 
        public int id { get; set; }
        public string name { get; set; }
        public double salary { get; set; }
    }
}
